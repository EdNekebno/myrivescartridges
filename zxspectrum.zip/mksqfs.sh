./rivemu -quiet -no-window -sdk -workspace -exec riv-mksqfs 0-start.sh 48.rom plus2.rom spectrum_palette.png zxspectrum $1.z80 $1.z80.cfg $1.z80.controller.cfg $1.sqfs -comp xz
./rivemu -no-loading -sdk $1.sqfs
